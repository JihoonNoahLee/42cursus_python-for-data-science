# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    count_in_list.py                                   :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: jihoolee <jihoolee@student.42SEOUL.kr>     +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/08/17 21:57:36 by jihoolee          #+#    #+#              #
#    Updated: 2024/08/17 21:58:16 by jihoolee         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

def count_in_list(lst: list[any], value: any) -> int:
    return lst.count(value)
